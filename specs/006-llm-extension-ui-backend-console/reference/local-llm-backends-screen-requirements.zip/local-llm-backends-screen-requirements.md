# Local LLM Backends Screen Requirements
## Detailed product and engineering requirements for the builtin Local LLM extension backend management surface

**Project:** nexus-dnn  
**Area:** Builtin extension `nexus.local-llm` → Backends screen  
**Primary target:** `llama.cpp` first  
**Future-ready target:** TensorRT-LLM, other backend families later  
**Platform priority:** Windows x64 with NVIDIA GPU first, Linux x64 second  
**Document status:** Proposed requirements draft

---

## 1. Executive summary

The current Backends screen exposes `Start`, `Stop`, and `Install Runtime` as flat actions on a profile detail panel. That is not enough for a local LLM runtime management experience.

The screen needs to communicate three distinct concepts clearly:

1. **Runtime installation** — obtaining and validating the backend executable package and its backend-specific dependencies.
2. **Profile configuration** — defining how a particular backend instance should run: backend family, acceleration mode, CUDA line, model, ports, context, and tuning defaults.
3. **Service lifecycle** — starting, stopping, restarting, and observing the running backend process.

Right now those concepts are visually mixed together. The result is ambiguity:

- `Start` is unclear if the runtime is not installed yet.
- `Stop` is unclear if nothing has ever been started.
- `Install Runtime` does not explain what will be installed, where it will live, what CUDA line it targets, or what validation steps will run.
- The screen is too passive for first-time setup and too weak for diagnostics once something fails.

This document reframes the screen as a **backend setup + operations console** for the Local LLM extension, beginning with `llama.cpp`.

---

## 2. Alignment with platform architecture

These requirements align with the platform principles already established for Nexus:

- The host remains the authoritative orchestrator for workflow state, scheduling, lifecycle, artifacts, and extension activation. Runtime workers stay isolated from the host process. fileciteturn0file2L31-L40
- Extensions may contribute runtime adapters, and `llama.cpp` belongs naturally in the **Native** runtime family rather than leaking backend-specific logic into the host core. fileciteturn0file11L46-L72
- The Rust host is already intended to supervise worker startup, stop, health checks, and runtime-family-specific adapters, which makes backend lifecycle management a first-class fit for this screen. fileciteturn0file1L34-L54
- The local LLM effort is explicitly intended to support builtin backend management, managed runtime installation, health, metrics, logs, and Windows-first `llama.cpp` execution. fileciteturn0file22

---

## 3. Current screen diagnosis

### 3.1 Observed issues

1. **Action ambiguity**
   - `Start` and `Stop` are always visible, but their meaning depends entirely on hidden state.
   - `Install Runtime` is the real first action, but it is visually treated like a peer to `Start` and `Stop`.

2. **No setup guidance**
   - The screen does not guide first-time users from empty state to a runnable backend.
   - There is no strong distinction between “profile exists” and “backend is actually usable.”

3. **No runtime ownership model visible in UI**
   - Users cannot see whether the runtime is shared, isolated, corrupted, outdated, partially installed, or tied to a particular CUDA line.

4. **No explicit compatibility story**
   - The screen does not explain why a specific `llama.cpp` build is being offered or blocked.
   - CUDA 12 vs CUDA 13 vs CPU should be explained, recommended, and validated before install.

5. **Weak failure UX**
   - Health, metrics, and logs exist conceptually, but setup failures need a dedicated install/diagnostics experience, not only a passive tab.

6. **No distinction between install-time logs and run-time logs**
   - Users need to know whether they are looking at installer output or backend service output.

7. **The empty state wastes the main panel**
   - When no profiles exist, the right panel shows blank technical fields instead of a structured onboarding flow.

### 3.2 Product conclusion

The Backends screen should become a **stateful workflow** rather than a static settings page.

---

## 4. Product goals

### 4.1 Primary goals

1. Make first-time `llama.cpp` setup obvious and reliable.
2. Make runtime installation isolated from other backends and future CUDA requirements.
3. Make the user understand exactly what is installed and what is merely configured.
4. Make backend lifecycle actions contextual instead of always-on.
5. Make failure and recovery first-class.
6. Prepare the same model for TensorRT-LLM later without redesigning the screen.

### 4.2 Secondary goals

1. Support expert users with advanced tuning and direct diagnostics.
2. Preserve clean architectural boundaries: generic host services, backend-specific extension logic.
3. Allow reproducible runtime installs and repair flows.
4. Surface backend readiness in a way that can later integrate with recipe/chat execution surfaces.

---

## 5. Core design stance

### 5.1 Separate these concepts rigorously

#### A. Runtime install
A **runtime install** is a concrete, versioned, validated installation of a backend package.

Examples:
- `llama.cpp b4970 windows-x64-cpu`
- `llama.cpp b4970 windows-x64-cuda12`
- `llama.cpp b4970 windows-x64-cuda13`

A runtime install is not a profile and is not a running process.

#### B. Backend profile
A **backend profile** is a user-owned configuration binding a runtime family to a concrete execution configuration.

Examples:
- `Qwen 7B GGUF – CUDA 12 – 8k context`
- `CPU fallback profile`
- `Testing profile – small quant – port 8123`

A profile references a runtime install and a model, plus launch/config defaults.

#### C. Runtime service instance
A **runtime service instance** is the actual running backend process started from a profile.

Examples:
- `llama-server.exe` started from profile `Qwen 7B GGUF – CUDA 12`
- stopped
- starting
- degraded
- failed

### 5.2 UX consequence

The screen must not flatten those three levels into three buttons.

---

## 6. Proposed information architecture

### 6.1 Screen structure

The Backends screen shall have three major layers:

1. **Left rail: Profiles and quick status**
2. **Main panel: Setup / Overview / Diagnostics for selected profile**
3. **Transient modal or drawer: runtime installation and repair flow**

### 6.2 Left rail

The left rail shall show backend profiles as the user’s primary objects.

Each profile item shall display:
- profile name
- backend family badge
- acceleration badge (`CPU`, `CUDA 12`, `CUDA 13`)
- model badge or `No model`
- state badge (`Draft`, `Runtime Missing`, `Ready`, `Running`, `Failed`, etc.)
- optional health indicator dot

The left rail shall support:
- create profile
- duplicate profile
- rename profile
- delete profile
- filter by backend family
- sort by last used / name / health state

### 6.3 Main panel modes

The main panel shall switch among these views depending on selected profile state:

1. **First-time onboarding** — no profile selected or no profiles exist
2. **Draft setup** — profile exists but missing runtime and/or model
3. **Ready overview** — profile fully configured but not running
4. **Live operations view** — profile is starting/running/degraded
5. **Failure diagnostics view** — profile failed to install, validate, or start

### 6.4 Modal/drawer for install

Runtime installation shall occur in a dedicated modal or drawer with:
- current phase
- progress bar
- byte progress when applicable
- detailed log stream
- cancellable operation
- final validation result
- copyable log output
- “Retry” / “Repair” / “Open Install Folder” / “Dismiss” actions

The install experience must not be hidden inside a small inline panel.

---

## 7. UX redesign requirements

## 7.1 Replace unconditional Start/Stop with contextual primary actions

The current fixed action bar shall be replaced with state-aware actions.

### Profile state → primary CTA mapping

| Profile state | Primary action | Secondary actions |
|---|---|---|
| No runtime selected | `Choose Runtime` | `Delete Profile` |
| Runtime selected but not installed | `Install Runtime` | `Change Runtime` |
| Runtime installed but not validated | `Validate Runtime` | `Repair`, `Reinstall` |
| No model selected | `Choose Model` | `Import Model`, `Open Model Browser` |
| Invalid config | `Fix Configuration` | `Reset Defaults` |
| Ready to run | `Start Backend` | `Test Boot`, `Advanced Config` |
| Starting | `View Startup Logs` | `Cancel Start` |
| Running | `Stop Backend` | `Restart`, `Open Logs`, `Open Metrics`, `Test Request` |
| Degraded | `Repair / Diagnose` | `Restart`, `Open Logs` |
| Failed | `View Failure Details` | `Retry`, `Repair`, `Reinstall Runtime` |

### Mandatory rule

`Start` and `Stop` shall never both appear as equally emphasized primary actions at the same time.

### Product rationale

This directly solves the user concern that the purpose of `Start`/`Stop` is currently unclear.

---

## 7.2 Add a setup stepper

Every selected profile shall show a compact setup stepper near the top:

1. Environment probed
2. Runtime chosen
3. Runtime installed
4. Runtime validated
5. Model selected
6. Configuration valid
7. Backend ready
8. Running

Each step shall show one of:
- not started
- in progress
- completed
- blocked
- failed

This gives the page a clear progression model.

---

## 7.3 Add a runtime card and a profile card

The main panel overview shall separate **runtime facts** from **profile facts**.

### Runtime card
Shows immutable or semi-stable installation facts:
- backend family
- upstream version/tag
- platform and architecture
- acceleration target
- install location
- binary path
- installed at
- checksum / integrity status
- validation result
- last repair time

### Profile card
Shows user-tunable execution configuration:
- profile name
- selected model
- context size
- threads
- gpu layers
- flash attention
- HTTP port / endpoint
- env overrides
- auto-start policy
- last started at

This split is essential because runtime and profile are different domain entities.

---

## 7.4 Add dedicated tabs

The right-hand detail area shall expose these tabs:

1. **Overview**
2. **Install**
3. **Health**
4. **Metrics**
5. **Logs**
6. **Config**
7. **Diagnostics**
8. **History**

### Tab intent

- **Overview**: summary, setup stepper, key actions
- **Install**: install record, version, asset, path, validation, repair/reinstall
- **Health**: current service status, PID, uptime, endpoint checks
- **Metrics**: throughput, active requests, cache, GPU memory
- **Logs**: runtime service logs only
- **Config**: editable profile launch configuration
- **Diagnostics**: structured failure object, environment probe, remediation hints
- **History**: install attempts, start/stop history, last failures, version changes

---

## 8. First-time setup flow requirements

## 8.1 Empty-state experience

When no backend profiles exist, the Backends screen shall not show empty technical detail rows.

Instead it shall show a guided empty-state panel with:
- explanation of what a backend profile is
- recommended first choice (`llama.cpp`)
- “Create Recommended Profile” CTA
- “Expert Setup” CTA
- “Why do I need a runtime?” help text

### Recommended first-time CTA

`Create Recommended llama.cpp Profile`

This action shall:
1. probe the environment
2. suggest CPU / CUDA 12 / CUDA 13 variants
3. create a draft profile with recommended defaults
4. take the user directly into the install flow

---

## 8.2 Environment probe before install

Before any runtime installation begins, the extension shall run an environment probe.

### Probe output shall include
- OS family
- architecture
- NVIDIA GPU presence
- detected CUDA-compatible environment or missing prerequisites
- candidate runtime assets
- recommended runtime asset
- blocked runtime assets with reasons
- expert override options

### UI behavior

The user shall see a “Compatibility” panel explaining:
- why a certain build is recommended
- why other builds are hidden or blocked
- what fallback options exist

---

## 8.3 Install flow phases

The runtime install modal shall show explicit install phases.

### Required phases for `llama.cpp`

1. Resolve version manifest
2. Resolve compatible asset for platform + acceleration
3. Download archive
4. Verify checksum or signed integrity metadata when available
5. Unpack into managed install directory
6. Discover expected binaries
7. Validate binary launchability
8. Run smoke boot / health check
9. Persist runtime install record
10. Mark runtime ready

Each phase shall emit a user-readable message and a machine-readable status event.

---

## 9. Llama.cpp-specific runtime ownership requirements

## 9.1 Isolation principle

`llama.cpp` must own its own runtime installation and must not depend on shared mutable runtime folders that could conflict with future TensorRT-LLM or other backends.

### Required rule

Each installed `llama.cpp` runtime shall live in a versioned, backend-specific managed root.

### Recommended path pattern

```text
~/.nexus/local-llm/runtimes/llamacpp/<version>/<platform>-<arch>-<acceleration>/
```

Example:

```text
~/.nexus/local-llm/runtimes/llamacpp/b4970/windows-x64-cuda12/
```

### Managed contents
- extracted upstream release asset
- resolved executable paths
- install manifest JSON
- validation results
- installer logs
- runtime-specific side files if needed

---

## 9.2 CUDA isolation for llama.cpp

The user requirement is that `llama.cpp` should take care of its own compatible CUDA runtime story.

### Product interpretation

For `llama.cpp`, the system shall treat CUDA compatibility as a property of the selected runtime asset, not as a global backend-agnostic assumption.

### Requirements

1. The installer shall select a `llama.cpp` release asset already aligned to the chosen CUDA line whenever upstream ships such an asset.
2. The install record shall persist the CUDA line as part of runtime identity.
3. The UI shall show the CUDA line explicitly as a runtime fact.
4. A `llama.cpp` CUDA 12 profile and a future TensorRT-LLM CUDA 12 profile must not share an installation root.
5. Runtime validation shall detect missing DLLs / dependent libraries and report the exact missing dependency.
6. If side-by-side runtime support files are needed for the selected asset, they shall be stored inside the same managed runtime root or a backend-scoped dependency subdirectory.
7. The user shall never need to manually browse for a `llama.cpp` executable after clicking install unless they explicitly choose a manual/expert mode.

### Important UX consequence

The install action must feel like:

> “Install a self-contained backend package that this profile can use.”

not:

> “Go figure out binaries and CUDA yourself.”

---

## 9.3 Runtime activation semantics

The system shall distinguish between:

- **Install Runtime** — put the selected backend package on disk and validate it
- **Activate Runtime for Profile** — bind that runtime install to the selected profile
- **Start Backend** — spawn the service process using that profile’s model and config

### Rule

Install must not imply process startup by default.

### Optional convenience

After a successful install, the UI may offer:
- `Start now`
- `Choose model`
- `Done`

---

## 10. Profile model requirements

## 10.1 Backend profile fields

A backend profile shall contain at minimum:
- profile id
- profile display name
- backend family
- runtime install reference
- acceleration target
- model install reference or local manual path
- model display name
- launch mode
- host/port
- context size
- threads
- batch size if applicable
- gpu layers
- flash attention toggle
- embeddings enabled flag if supported
- metrics enabled flag
- auto-start policy
- startup timeout
- health check interval
- log retention policy
- created_at
- updated_at
- last_started_at
- last_error

## 10.2 Profile states

Profile state must be stronger than a single generic `status` field.

### Required states
- `draft`
- `runtime_missing`
- `runtime_installing`
- `runtime_validating`
- `model_missing`
- `config_invalid`
- `ready`
- `starting`
- `running`
- `stopping`
- `stopped`
- `degraded`
- `failed`

### Rules

1. `Start Backend` is enabled only in `ready` or `stopped`.
2. `Stop Backend` is enabled only in `starting`, `running`, or `degraded`.
3. `Install Runtime` is enabled in `runtime_missing`, `failed`, or expert repair paths.
4. `Choose Model` is emphasized in `model_missing`.

---

## 11. Runtime installation requirements

## 11.1 Install source

For `llama.cpp`, the extension shall install from the pinned version manifest embedded with the extension.

### Required manifest data
- preferred version
- release tag
- platform/acceleration asset mapping
- expected binary names
- checksum when available
- install compatibility notes

## 11.2 Installer behavior

The installer shall:
1. resolve the best asset from the manifest
2. download the archive into a backend-scoped cache
3. verify integrity
4. unpack atomically into a temp directory
5. promote temp directory into final install root only on success
6. persist install record
7. keep failed installs quarantined for inspection or clean them safely

## 11.3 Progress UX

The install popup shall show:
- phase name
- percent complete
- bytes downloaded / total bytes
- current file being processed
- elapsed time
- estimated remaining time when confidence is reasonable
- raw log panel

## 11.4 Cancellation

The user shall be able to cancel an install while it is downloading or unpacking.

### Cancellation rules
- partial downloads may be retained for resume if supported
- incomplete unpacked runtime shall not be marked valid
- UI shall clearly label cancelled installs as `Cancelled`, not `Failed`

## 11.5 Repair and reinstall

The screen shall support:
- validate existing install
- repair missing files when possible
- reinstall over same version
- upgrade to newer pinned version later
- uninstall unused runtime install

---

## 12. Runtime validation requirements

## 12.1 Validation must be explicit

Installation is not enough. Validation must prove the runtime is usable.

### Validation checks for `llama.cpp`
- expected executable exists
- executable launches with `--help` or equivalent lightweight check
- service binary can start with a minimal test configuration
- health endpoint responds within timeout
- version can be resolved
- required model argument validation works
- runtime folder permissions are correct
- log capture directory is writable

## 12.2 Validation result object

Validation results shall include:
- outcome (`passed`, `warning`, `failed`)
- version string if detected
- binary path used
- time taken
- structured failure if any
- remediation hint

---

## 13. Model binding requirements

The Backends screen is incomplete if it manages only runtime and ignores model binding.

### Required model features from this screen
- choose an already registered compatible model
- import a local GGUF file manually
- open model browser to download compatible models
- validate chosen model against selected backend family
- show model file path / identity / size / quantization hint

### Start gating rule

A profile cannot transition to `ready` without a valid model selection unless the backend explicitly supports model-less startup, which `llama.cpp` does not for the default chat path.

---

## 14. Running backend lifecycle requirements

## 14.1 Start behavior

When the user clicks `Start Backend`, the system shall:
1. validate profile config
2. validate runtime install exists and is usable
3. validate model path exists
4. reserve or validate network port
5. generate effective launch command
6. start the managed process
7. capture stdout/stderr to runtime logs
8. poll health endpoint until ready or timeout
9. update profile state to `running` or `failed`

## 14.2 Stop behavior

When the user clicks `Stop Backend`, the system shall:
1. send graceful termination request first
2. wait for configurable timeout
3. escalate to force terminate if needed
4. persist stop reason
5. update profile state to `stopped`

## 14.3 Restart behavior

Restart shall be a first-class action, not an implied stop+start hidden elsewhere.

## 14.4 Test boot

The UI shall expose `Test Boot` for validation without leaving the profile in a running steady state.

This is useful for:
- verifying install
- verifying model load
- confirming port and health before user commits to full startup

---

## 15. Logging and diagnostics requirements

## 15.1 Separate install logs from runtime logs

### Install logs
Generated during download / unpack / validation.

### Runtime logs
Generated while `llama-server` is running or starting.

They shall never be mixed in the same default viewer without a clear source label.

## 15.2 Log viewer capabilities

The log viewer shall support:
- level filtering
- source filtering (`installer`, `runtime`, `health-check`, `process-supervisor`)
- search
- copy all
- download log bundle
- jump to first error
- preserve logs across restarts until retention cleanup

## 15.3 Structured diagnostics pane

On failure, the Diagnostics tab shall show:
- failure category
- concise user-facing message
- technical detail
- effective command
- binary path
- model path
- exit code / signal
- last N log lines
- environment probe snapshot
- remediation hints

---

## 16. Health and metrics requirements

## 16.1 Health panel

The health panel shall show:
- backend status
- PID
- uptime
- version
- endpoint URL
- model loaded state
- last health check time
- last successful request time

## 16.2 Metrics panel

For `llama.cpp`, when available, the metrics panel shall normalize and display:
- prompt tokens/s
- generation tokens/s
- total requests
- active requests
- KV cache usage
- GPU memory used
- queue depth if available
- average first-token latency if derivable

## 16.3 Metrics fallbacks

If metrics are unavailable for the selected backend or runtime mode, the panel shall say so explicitly instead of showing blank placeholders.

---

## 17. Windows-first requirements for llama.cpp

## 17.1 Windows support is not optional

The first credible vertical slice shall work on Windows x64 with NVIDIA GPUs because that is the primary target for this screen.

## 17.2 Windows-specific checks

During probe and validation, the system shall check:
- OS version compatibility
- x64 architecture
- GPU detectability
- selected asset compatibility
- runtime folder path safety
- file locking / antivirus interference when relevant
- missing DLLs on launch
- port conflicts on loopback

## 17.3 Recommended defaults

On a Windows x64 + NVIDIA system, the UI shall:
- recommend CUDA build when compatible
- recommend CPU build as fallback
- explain why CUDA 12 or CUDA 13 was selected or blocked

---

## 18. Screen content requirements

## 18.1 Overview tab layout

The Overview tab shall include, top to bottom:

1. setup stepper
2. contextual CTA row
3. profile summary card
4. runtime summary card
5. model summary card
6. quick diagnostics banner if warnings/failures exist
7. recent activity list

## 18.2 Install tab layout

The Install tab shall include:
- selected runtime asset
- version
- acceleration line
- install location
- last install attempt
- validation status
- `Install`, `Repair`, `Revalidate`, `Reinstall`, `Uninstall` actions
- inline latest install result summary

## 18.3 Config tab layout

The Config tab shall group fields into sections:

### Runtime launch
- port
- host binding
- startup timeout
- health timeout

### Model load
- model path
- context size
- gpu layers
- batch size

### Performance
- threads
- flash attention
- continuous batching when supported later

### Observability
- metrics enabled
- verbose logging
- log retention

### Safety
- loopback only toggle
- auto-start toggle

---

## 19. Backend screen API requirements

The Local LLM extension and host integration shall expose API operations sufficient to drive the new UX.

### Required commands / methods
- `llm.probe_environment`
- `llm.list_runtime_candidates`
- `llm.install_runtime`
- `llm.cancel_install`
- `llm.get_install_status`
- `llm.get_install_logs`
- `llm.validate_runtime`
- `llm.repair_runtime`
- `llm.uninstall_runtime`
- `llm.list_profiles`
- `llm.create_profile`
- `llm.update_profile`
- `llm.delete_profile`
- `llm.get_profile_detail`
- `llm.bind_runtime_to_profile`
- `llm.bind_model_to_profile`
- `llm.start_profile`
- `llm.stop_profile`
- `llm.restart_profile`
- `llm.test_boot_profile`
- `llm.get_backend_health`
- `llm.get_metrics`
- `llm.get_backend_logs`
- `llm.get_diagnostics`
- `llm.list_profile_history`

### API design rule

The UI must never need to infer backend state from button availability alone. State must come from explicit typed payloads.

---

## 20. Event model requirements

The event model shall distinguish install lifecycle from runtime lifecycle.

### Required install events
- `backend.install.started`
- `backend.install.progress`
- `backend.install.phase.changed`
- `backend.install.complete`
- `backend.install.cancelled`
- `backend.install.failed`

### Required runtime lifecycle events
- `backend.state.changed`
- `backend.health.changed`
- `backend.metrics.updated`
- `backend.logs.appended`
- `backend.diagnostics.updated`

### Required profile config events
- `backend.profile.updated`
- `backend.profile.deleted`
- `backend.profile.runtime_bound`
- `backend.profile.model_bound`

---

## 21. Data model requirements

The current conceptual model already points in the right direction: runtime installs, backend profiles, health, and metrics should be distinct concerns. This screen should enforce that boundary in storage and API shape.

### RuntimeInstall must include
- install id
- backend family
- upstream version
- asset name
- platform
- arch
- acceleration line
- install root
- checksum / integrity state
- binary paths
- install state
- validation result
- install log path
- created_at
- updated_at

### BackendProfile must include
- runtime_install_id
- model_install_id
- current state
- last_error
- last_pid
- effective endpoint
- serialized launch config
- last_started_at
- last_stopped_at

### BackendRunHistory entry should include
- profile id
- action (`install`, `validate`, `start`, `stop`, `restart`, `repair`)
- result
- started_at
- finished_at
- version/runtime snapshot
- summary message
- diagnostics reference

---

## 22. Failure model requirements

The screen shall treat these failure classes explicitly:

1. manifest resolution failure
2. network download failure
3. checksum or integrity failure
4. archive extraction failure
5. binary missing after extraction
6. launch failure
7. missing DLL / dependency failure
8. port bind failure
9. model file missing
10. model load failure
11. health timeout
12. unexpected process exit
13. metrics unavailable
14. incompatible CUDA line

For each class, the UI shall present:
- a plain-language explanation
- a technical detail section
- a likely fix
- the next best action button

---

## 23. Security and isolation requirements

## 23.1 Process isolation

The backend runtime shall remain outside host memory space, consistent with the platform’s extension isolation model. fileciteturn0file1L156-L160

## 23.2 Filesystem boundaries

Managed runtime installs shall live in backend-scoped directories.

## 23.3 Network defaults

Local backends shall bind to loopback by default.

## 23.4 Permission clarity

The screen shall clearly indicate when a backend requires:
- process spawning
- filesystem writes
- network loopback access
- optional remote network access for downloads

---

## 24. Accessibility and usability requirements

1. Every state badge must have text, not color only.
2. Install progress must be readable without relying on animations.
3. Logs must be keyboard navigable.
4. Failure banners must remain visible until dismissed or resolved.
5. Copyable commands and paths must have dedicated affordances.
6. Advanced fields shall be collapsible, not hidden behind a different screen.

---

## 25. Specific answer to the Start/Stop problem

The point of `Start` and `Stop` becomes valid only after the screen models backend lifecycle properly.

### Revised meaning

- **Install Runtime** = get a usable backend package onto disk
- **Activate / Bind Runtime** = choose which installed runtime this profile uses
- **Start Backend** = launch the actual `llama-server` service for this profile
- **Stop Backend** = terminate the running service instance
- **Restart Backend** = explicit lifecycle action for a running or degraded instance

### Therefore

The current `Start`/`Stop` buttons are not wrong conceptually. They are wrong **as top-level unconditional actions**.

They should remain in the screen, but only when the profile is in a lifecycle state where they are meaningful.

---

## 26. Recommended visual redesign

## 26.1 Header row

Instead of:
- Start
- Stop
- Install Runtime

Use:
- primary contextual CTA
- secondary dropdown: `More actions`
- state pill
- last activity text

Example when profile is not ready:
- `Install Runtime` (primary)
- `More actions ▾`
- `Draft` badge

Example when profile is ready:
- `Start Backend` (primary)
- `More actions ▾` → `Test Boot`, `Edit Config`, `Repair Runtime`
- `Ready` badge

Example when profile is running:
- `Stop Backend` (primary, danger)
- `Restart`
- `Open Logs`
- `Running` badge

## 26.2 Summary strip

A compact strip shall show:
- Backend: `llama.cpp`
- Runtime: `b4970 / CUDA 12`
- Model: `Qwen2.5-7B-Instruct-Q4_K_M.gguf`
- Endpoint: `127.0.0.1:8084`
- Health: `Ready`

## 26.3 Install progress presentation

During install, show a modal with a structured step list on the left and live logs on the right.

---

## 27. Acceptance criteria

### AC-01 — first-time setup
A fresh user can create a recommended `llama.cpp` profile from the empty state and reach `Ready` without manually downloading a binary.

### AC-02 — install transparency
The install popup shows progress phases, logs, and final validation result.

### AC-03 — runtime isolation
The installed `llama.cpp` runtime lives under a backend-specific managed root and does not reuse a TensorRT-LLM install path.

### AC-04 — stateful CTA
The main CTA changes according to profile state and never shows meaningless lifecycle actions.

### AC-05 — model gating
The user cannot start a profile without a valid model binding.

### AC-06 — repairability
If the installed runtime becomes invalid, the screen surfaces a repair or reinstall path.

### AC-07 — diagnostics
If startup fails, the user sees structured failure diagnostics and relevant last logs.

### AC-08 — Windows target
On Windows x64 with NVIDIA GPU, the screen recommends an appropriate `llama.cpp` CUDA build and explains why.

### AC-09 — runtime log separation
Installer logs and backend runtime logs are shown separately with clear labeling.

### AC-10 — persistence
Installed runtime records, profile state, and last validation results persist across application restarts.

---

## 28. Non-functional requirements

### NFR-01 — reliability
A failed install must never be marked as usable.

### NFR-02 — reversibility
Install, validate, start, stop, and repair operations must leave auditable history.

### NFR-03 — observability
Every install and lifecycle phase must emit structured events.

### NFR-04 — performance
The screen must remain responsive while install logs stream and health polling continues.

### NFR-05 — extensibility
The same screen architecture must accommodate TensorRT-LLM later without rethinking the core model.

### NFR-06 — clarity
Users must always be able to answer three questions quickly:
- What runtime is installed?
- Is this profile runnable?
- What failed and what should I do next?

---

## 29. Implementation slicing recommendation

### Slice 1 — llama.cpp setup foundation
- environment probe
- recommended profile creation
- install popup
- runtime install record
- runtime validation
- contextual CTA logic

### Slice 2 — profile readiness and model binding
- model selection/import from backend screen
- profile setup stepper
- start gating
- improved detail cards

### Slice 3 — operations and diagnostics
- start/stop/restart/test boot
- runtime log viewer
- diagnostics tab
- history tab

### Slice 4 — polish and repair
- repair / reinstall flows
- install history
- path utilities
- richer compatibility explanations

---

## 30. Recommended next implementation decision

The best next concrete step is:

**Refactor the Backends screen domain model so that `RuntimeInstall`, `BackendProfile`, and `RunningService` are treated as separate stateful entities in both API responses and UI rendering.**

That one decision will fix the button ambiguity and unlock a much stronger `llama.cpp` onboarding and diagnostics experience.

---

## 31. Optional follow-up document

After this screen-level requirements document, the next useful companion spec would be:

**`llama.cpp runtime installation and validation protocol`**

That doc should define:
- exact install root layout
- download cache layout
- runtime manifest JSON shape
- validation command sequence
- error taxonomy
- repair semantics
- Windows-specific dependency checks

