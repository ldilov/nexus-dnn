/**
 * Spec 035 — Dependencies tab.
 *
 * Generic step-list driven entirely by the host's `GET /dependencies` response.
 * Renders any extension's plan with no per-extension code paths.
 */
import { useCallback, useMemo, useState } from "react";
import { toast } from "sonner";
import useSWR from "swr";

import {
  cancelInstall,
  fetchDependencies,
  retryStep,
  startInstall,
} from "../../../services/extension_dependencies_client";
import { shortenSize } from "../step_type_presentation";
import { useInstallProgress } from "../use_install_progress";
import { StepRow } from "../components/step_row";
import * as s from "./dependencies.tab.css";

export interface DependenciesTabProps {
  extensionId: string;
}

export function DependenciesTab({ extensionId }: DependenciesTabProps) {
  const swrKey = `/extensions/${extensionId}/dependencies`;
  const { data, error, isLoading, mutate } = useSWR(swrKey, () =>
    fetchDependencies(extensionId),
  );
  const progress = useInstallProgress(extensionId, swrKey);
  const [busy, setBusy] = useState(false);

  const handleInstallAll = useCallback(async () => {
    setBusy(true);
    try {
      await startInstall(extensionId);
      toast.success("Install started", { description: extensionId });
      void mutate();
    } catch (err: unknown) {
      toast.error("Failed to start install", {
        description: err instanceof Error ? err.message : String(err),
      });
    } finally {
      setBusy(false);
    }
  }, [extensionId, mutate]);

  const handleReinstallAll = useCallback(async () => {
    const ok = window.confirm(
      "Reinstall every dependency from scratch?\n\nThis re-runs every step, including downloads — it can take a while and re-fetches model artifacts even if they're already on disk.",
    );
    if (!ok) return;
    setBusy(true);
    try {
      await startInstall(extensionId, { force: true });
      toast.success("Reinstall started", { description: extensionId });
      void mutate();
    } catch (err: unknown) {
      toast.error("Failed to start reinstall", {
        description: err instanceof Error ? err.message : String(err),
      });
    } finally {
      setBusy(false);
    }
  }, [extensionId, mutate]);

  const handleCancel = useCallback(async () => {
    setBusy(true);
    try {
      await cancelInstall(extensionId);
      toast("Cancellation requested");
      void mutate();
    } catch (err: unknown) {
      toast.error("Cancel failed", {
        description: err instanceof Error ? err.message : String(err),
      });
    } finally {
      setBusy(false);
    }
  }, [extensionId, mutate]);

  const handleRetry = useCallback(
    async (stepId: string) => {
      setBusy(true);
      try {
        await retryStep(extensionId, stepId);
        toast.success(`Retrying ${stepId}`);
        void mutate();
      } catch (err: unknown) {
        toast.error("Retry failed", {
          description: err instanceof Error ? err.message : String(err),
        });
      } finally {
        setBusy(false);
      }
    },
    [extensionId, mutate],
  );

  const installActive = progress.active || data?.steps.some((s) => s.status === "running") || false;

  const satisfiedById = useMemo(() => {
    const map: Record<string, boolean> = {};
    if (data) for (const step of data.steps) map[step.id] = step.satisfied;
    return map;
  }, [data]);

  if (isLoading) {
    return <div className={s.emptyState}>Loading dependencies…</div>;
  }
  if (error) {
    return (
      <div className={s.emptyState}>
        Could not load dependencies: {error instanceof Error ? error.message : String(error)}
      </div>
    );
  }
  if (!data || data.steps.length === 0) {
    return (
      <div className={s.emptyState}>
        This extension declares no managed dependencies.
      </div>
    );
  }

  const remainingLabel =
    data.total_remaining_bytes > 0
      ? `${shortenSize(data.total_remaining_bytes)} remaining`
      : data.all_satisfied
        ? "All dependencies satisfied"
        : "Some steps need attention";
  const stepCounts = `${data.steps.filter((step) => step.satisfied).length} of ${data.steps.length} satisfied`;

  return (
    <div className={s.root}>
      <header
        className={`${s.banner}${data.all_satisfied ? ` ${s.allSatisfied}` : ""}`}
      >
        <div className={s.bannerText}>
          <span className={s.bannerTitle}>{stepCounts}</span>
          <span className={s.bannerSubtitle}>{remainingLabel}</span>
        </div>
        <div className={s.bannerActions}>
          {installActive ? (
            <button
              type="button"
              className={s.cancelButton}
              onClick={handleCancel}
              disabled={busy}
            >
              Cancel
            </button>
          ) : (
            <>
              <button
                type="button"
                className={s.reinstallButton}
                onClick={handleReinstallAll}
                disabled={busy}
                title="Re-run every step from scratch, ignoring already-installed state"
              >
                Reinstall everything
              </button>
              <button
                type="button"
                className={s.installButton}
                onClick={handleInstallAll}
                disabled={busy || data.all_satisfied}
              >
                {data.all_satisfied ? "All set" : "Install all"}
              </button>
            </>
          )}
        </div>
      </header>

      <div className={s.stepList}>
        {data.steps.map((step) => {
          const upstreamSatisfied = step.requires.every((req) => satisfiedById[req] ?? false);
          return (
            <StepRow
              key={step.id}
              step={step}
              upstreamSatisfied={upstreamSatisfied}
              installActive={installActive}
              onInstallOnly={handleRetry}
              onRetry={handleRetry}
              onReinstall={handleRetry}
            />
          );
        })}
      </div>
    </div>
  );
}
